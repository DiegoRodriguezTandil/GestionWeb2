define(function() {
	return (/\?/);
});
