     
angular.module('RDash')
    .factory('AuthTokenService', ['$window', AuthTokenService])
    .factory('AuthService', ['$http', '$q', 'UrlService','AuthTokenService', AuthService])
    .factory('AuthInterceptorService', ['$q', '$location', 'AuthTokenService', AuthInterceptorService]);
    
angular.module('RDash')
    .config(function ($httpProvider) {
        $httpProvider.interceptors.push('AuthInterceptorService');
    });
    
        
function AuthTokenService($window) {
    
    var getToken = function() {
        return $window.localStorage.getItem('token');
//        return $window.sessionStorage.getItem('token');
    };
    
    var setToken = function(token) {
        if(token)
            $window.localStorage.setItem('token',token);
//            $window.sessionStorage.setItem('token',token);
        else
            $window.localStorage.removeItem('token');
//            $window.sessionStorage.removeItem('token');
    };
        
    return {
        getToken: getToken,
        setToken: setToken,
    };    
};
           
        
function AuthService($http, $q, UrlService, AuthTokenService) {
    
    var login = function(username, password) {    
        return $http.post(UrlService.auth_login,
        {
            username: username,
            password: password
        })
        .success(function (data){
            AuthTokenService.setToken(data.access_token);
            return data;
        });
    }
    
    var logout = function(){
        AuthTokenService.setToken();
    };
    
    var isLogged = function() {
        if (AuthTokenService.getToken())
            return true;
        return false;
    }
          
    return {
        login: login,
        logout: logout,
        isLogged: isLogged,
    };    
};
           
        
function AuthInterceptorService($q, $location, AuthTokenService) {
    
    var request = function(config){
        var token = AuthTokenService.getToken();
        
        if(token){
            config.headers.Authorization = 'Bearer ' + token;            
        }
        
        return config;
    };
    
    var responseError = function(response) {
        
        if(response.status == 403) {
            AuthTokenService.setToken();
            $location.path('/');
        }
        
        return $q.reject(response);
    }
          
    return {
        request: request,
        responseError: responseError,
    };    
};           
           
     
