angular.module('RDash')
    .factory('UrlService', [UrlService]);
        
function UrlService() {
    return {
        // User Service
        user_changePassword:    'http://localhost/gestionweb2service/user/changePassword',
        user_profile:           'http://localhost/gestionweb2service/user/profile',
        // Talonario URL - Invoices URL Service
        talonarioService:       'http://localhost/gestionweb2service/ciudad',
        // Auth Service
        auth_login:             'http://localhost/gestionweb2service/user/login'
    };    
};
           
     
