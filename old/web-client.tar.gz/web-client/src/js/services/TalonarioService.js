
//angular.module('RDash')
//    .factory('talonarioRepository', talonarioRepository);
//        
//function talonarioRepository() {
//    return {
//        getAllDocuments: function() {
//           return 'hola';
//        },
//        getDocumentById: function(id) {
//           return 'Factura '+id;
//        },
//    };
//};    
//     
     
angular.module('RDash')
    .factory('talonarioService', ['$http', 'UrlService', TalonarioService]);
        
function TalonarioService($http, UrlService) {
    
    var getAllDocuments = function() {
        return $http.get(UrlService.talonarioService)
                .success(function(response){
                    console.log(response);
                    return response.data;
                });
    };
    
    var getDocumentById = function(id) {
           return 'Factura '+id;
        };
        
    return {
        getAllDocuments: getAllDocuments,
        getDocumentById: getDocumentById,
    };    
};
           
     
