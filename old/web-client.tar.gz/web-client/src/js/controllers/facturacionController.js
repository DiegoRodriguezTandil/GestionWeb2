/**
 * Facturacion Controller
 */

angular.module('RDash')
    .controller('FacturacionController', [
        '$scope', 
        '$cookieStore', 
        '$modal',
        'talonarioService', 
        talonarioController]);

function talonarioController($scope, $cookieStore, $modal, talonarioService) {
    /**
     * Sidebar Toggle & Cookie Control
     */
    var mobileView = 992;
    
    onFacturaComplete = function(data) {
        console.log(data);
    };
    
    onFacturaError = function(reason){
        console.log(reason);
    };
    
    talonarioService.getAllDocuments()
        .success(onFacturaComplete);
//    console.log(talonarioService.getDocumentById(8));

    $scope.nuevaFactura = function(){
        var modalInstance = $modal.open({
            animation: true,
            templateUrl: 'templates/talonario/formFactura.html',
            controller: 'FacturaController',
            size: 'lg',
            resolve: {
                  item: 1 // id de la factura a editar o null en el caso de nueva
            }
        });        
    };
        
    $scope.getWidth = function() {
        return window.innerWidth;
    };

    $scope.$watch($scope.getWidth, function(newValue, oldValue) {
        if (newValue >= mobileView) {
            if (angular.isDefined($cookieStore.get('toggle'))) {
                $scope.toggle = ! $cookieStore.get('toggle') ? false : true;
            } else {
                $scope.toggle = true;
            }
        } else {
            $scope.toggle = false;
        }

    });
    

    $scope.toggleSidebar = function() {
        $scope.toggle = !$scope.toggle;
        $cookieStore.put('toggle', $scope.toggle);
    };

    window.onresize = function() {
        $scope.$apply();
    };
}


angular.module('RDash')
    .controller('FacturaController', [
        '$scope', 
        '$modalInstance',
        'talonarioService', 
        FacturaController]);

function FacturaController($scope, $modalInstance, talonarioService) {
    $scope.id = null;
    
    $scope.fechaDatePicker = {
        open: false,
    }
    
    $scope.fechaDatePickerOptions = {
        formatYear: 'yyyy',
        startingDay: 1        
    }
    
    $scope.factura = {
        id: null,
        nroTalonario: null,
        nroFormulario: null,
        TipoFormulario_id: null,
        fecha: new Date(),
    }
    
    $scope.aceptar = function(){
        $modalInstance.close($scope.factura);        
    }
    
    $scope.cancelar = function(){
        $modalInstance.dismiss('cancel');
    }
    
    $scope.fechaDatePickerOpen = function(event) {
        $scope.fechaDatePicker.open = true;
    };
    
}
