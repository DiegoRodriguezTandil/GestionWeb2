'use strict';

/**
 * Route configuration for the RDash module.
 */
angular.module('RDash')
    .config(['$stateProvider', '$urlRouterProvider',
        function($stateProvider, $urlRouterProvider) {

            // For unmatched routes
            $urlRouterProvider.otherwise('/');

            // Application routes
            $stateProvider
                .state('login', {
                    url: '/login',
                    views:{
                        content: {
                            templateUrl: 'templates/login.html'
                        }
                    }
                })            
                .state('logout', {
                    url: '/logout',
                    access: {
                        requiresLogin: true
                    },
                    views:{
                        content: {
                            templateUrl: 'templates/logout.html',
                        }
                    }
                })            
                .state('index', {
                    url: '/',
                    access: {
                        requireLogin: true
                    },
                    views:{
                        sidebar: {
                            templateUrl: 'templates/sidebar.html',                            
                        },
                        headerbar: {
                            templateUrl: 'templates/header-bar.html',                            
                        },
                        content: {
                            templateUrl: 'templates/dashboard.html',
                        }
                    }
                })
                .state('tables', {
                    url: '/tables',
                    access: {
                        requireLogin: true
                    },
                    views:{
                        sidebar: {
                            templateUrl: 'templates/sidebar.html',                            
                        },
                        headerbar: {
                            templateUrl: 'templates/header-bar.html',                            
                        },
                        content: {
                            templateUrl: 'templates/tables.html',
                        }
                    }
                })
                .state('facturacion', {
                    url: '/facturacion',
                    access: {
                        requireLogin: true
                    },
                    views:{
                        sidebar: {
                            templateUrl: 'templates/sidebar.html',                            
                        },
                        headerbar: {
                            templateUrl: 'templates/header-bar.html',                            
                        },
                        content: {
                            templateUrl: 'templates/facturacion.html',
                        }
                    }
                });
        }
    ]);
    
angular.module('RDash')    
    .run(['$rootScope','$state','AuthService',
        function($rootScope,$state,AuthService){
            $rootScope.$on("$stateChangeStart", function (event, next, current) {
                if (next.access !== undefined) {                
                    if(!AuthService.isLogged()){
                        event.preventDefault()
                        $state.go('login');
                    }
                }
            });
        }
    ]);