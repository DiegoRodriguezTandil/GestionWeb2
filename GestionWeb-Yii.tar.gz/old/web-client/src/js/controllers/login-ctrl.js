/**
 * Master Controller
 */

angular.module('RDash')
    .controller('LoginController', [
        '$scope', '$cookieStore', '$location', 'AuthService', '$timeout', LoginController]);

function LoginController($scope, $cookieStore, $location, AuthService, $timeout) {
    /**
     * Sidebar Toggle & Cookie Control
     */
    var mobileView = 992;
    
    $scope.user = {
        username: null,
        password: null        
    };
    
    var successLoginAlert = {
        show: false,
        type: 'success',
        msg: 'Acceso exitoso'
    };
    var errorLoginAlert = {
        show: false,
        type: 'danger',
        msg: 'Error de Nombre de usuario o Contraseña'
    };
    
    $scope.alert = successLoginAlert;
    
    $scope.processing = false;
    
    $scope.loginSubmit = function() {
        debugger;
        $scope.processing = true;
        AuthService
            .login($scope.user.username, $scope.user.password)
            .then(
                function(data){
                    debugger;
                    $scope.alert = successLoginAlert;
                    $scope.alert.show = true;            
                    $timeout(function(){
                        $location.path('/');
                    }, 1000);
                },
                function(error) {
                    debugger;
                    console.log(error);
                    if(error.status == 422){
                        $scope.alert = errorLoginAlert;
                        $scope.alert.show = true;            
                        $timeout(function(){
                            $scope.alert.show = false;
                        }, 5000);                    
                    }
                }
            )
            .finally(function() {
                $scope.processing = false;
            });
    };
            
    $scope.getWidth = function() {
        return window.innerWidth;
    };

    $scope.$watch($scope.getWidth, function(newValue, oldValue) {
        if (newValue >= mobileView) {
            if (angular.isDefined($cookieStore.get('toggle'))) {
                $scope.toggle = ! $cookieStore.get('toggle') ? false : true;
            } else {
                $scope.toggle = true;
            }
        } else {
            $scope.toggle = false;
        }

    });
    

    $scope.toggleSidebar = function() {
        $scope.toggle = !$scope.toggle;
        $cookieStore.put('toggle', $scope.toggle);
    };

    window.onresize = function() {
        $scope.$apply();
    };
}