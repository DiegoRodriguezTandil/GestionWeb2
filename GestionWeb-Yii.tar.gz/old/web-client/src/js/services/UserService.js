angular.module('RDash')
    .factory('UserService', ['$http', UserService]);
        
function UserService($http) {
    
    var user = {
        username: null,
        password: null,
        fullname: 'Administrador',
    };

    var _changePassword = function(oldPassword, newPassword){
        return $http.get(UrlService.user_changePassword,
        {
            oldPassword: oldPassword,
            newPassword: newPassword
        })
        .success(function (data){
            console.log('Password Cambiado Correctamente');
            return data;
        });
    };
    
    var _profile = function(){
        return $http.get(UrlService.user_profile)
        .success(function (data){
            console.log('Perfil de Usuario');
            return data;
        });
    }
    
    return {
        user: user,
        changePassword: _changePassword,
        profile: _profile
    };    
};
           
     
