<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=gestionweb',
    'username' => 'root',
    'password' => 'mysqlpass',
    'charset' => 'utf8',
];
